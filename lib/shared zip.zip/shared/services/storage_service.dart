import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'firebase_service.dart';

class StorageService {
  static final _storage = FirebaseStorage.instance;
  static final _picker  = ImagePicker();

  /// Opens the photo gallery, uploads the selected image, and returns the URL.
  static Future<String?> uploadFloorPlan(String floorId) async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 2000, maxHeight: 2000,
      imageQuality: 85,
    );
    if (image == null) return null;

    final ref = _storage.ref('floor_plans/$kHomeId/$floorId.jpg');
    final snapshot = await ref.putFile(
      File(image.path),
      SettableMetadata(contentType: 'image/jpeg'),
    );
    return snapshot.ref.getDownloadURL();
  }
}