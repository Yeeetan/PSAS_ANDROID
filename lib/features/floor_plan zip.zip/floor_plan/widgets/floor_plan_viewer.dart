import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:photo_view/photo_view.dart';
import '../../../app/theme.dart';
import '../models/floor_model.dart';
import '../models/pin_model.dart';
import '../../../shared/models/device_model.dart';
import 'pin_widget.dart';
import 'device_bottom_sheet.dart';

class FloorPlanViewer extends StatelessWidget {
  final FloorModel floor;
  final List<DeviceModel> devices;
  final bool editMode;
  final void Function(double xPct, double yPct)? onLongPress;
  final void Function(PinModel)? onPinDelete;

  const FloorPlanViewer({
    super.key,
    required this.floor,
    required this.devices,
    this.editMode = false,
    this.onLongPress,
    this.onPinDelete,
  });

  @override
  Widget build(BuildContext context) {
    if (floor.planImageUrl == null) return _placeholder();

    return LayoutBuilder(builder: (context, constraints) {
      final w = constraints.maxWidth;
      final h = constraints.maxHeight;

      return Stack(
        children: [
          // Pan/zoom image
          GestureDetector(
            onLongPressStart: editMode
                ? (d) => onLongPress?.call(
                (d.localPosition.dx / w).clamp(0.0, 1.0),
                (d.localPosition.dy / h).clamp(0.0, 1.0))
                : null,
            child: PhotoView(
              imageProvider: CachedNetworkImageProvider(floor.planImageUrl!),
              minScale: PhotoViewComputedScale.contained,
              maxScale: PhotoViewComputedScale.covered * 3,
              backgroundDecoration: const BoxDecoration(color: AppColors.surface),
            ),
          ),
          // Pins
          ...floor.pins.map((pin) {
            final hasActive = pin.linkedDeviceIds
                .any((id) => devices.any((d) => d.id == id && d.isOn));
            return Positioned(
              left: pin.xPct * w - 19, // -19 = half of pin width (38/2)
              top:  pin.yPct * h - 19,
              child: PinWidget(
                label:           pin.label,
                hasActiveDevice: hasActive,
                editMode:        editMode,
                onTap: () {
                  if (!editMode) DeviceBottomSheet.show(context, pin);
                },
                onDelete: () => onPinDelete?.call(pin),
              ),
            );
          }),
          // Edit hint banner
          if (editMode)
            Positioned(
              bottom: 20, left: 0, right: 0,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.65),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text('Long-press to drop a pin',
                      style: TextStyle(color: Colors.white, fontSize: 12)),
                ),
              ),
            ),
        ],
      );
    });
  }

  Widget _placeholder() => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.map_outlined, size: 64, color: AppColors.textHint),
        const SizedBox(height: 12),
        const Text('No floor plan uploaded', style: TextStyle(fontSize: 14, color: AppColors.textSecondary)),
        if (!editMode)
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text('Go to Settings → Floor setup',
                style: TextStyle(fontSize: 12, color: AppColors.textHint)),
          ),
      ],
    ),
  );
}